<div class="card text-bg-dark">
    <img src="Images/bg_final.png" class="card-img" alt="bg_img" style="width: 100vw;height: 85vh;opacity:0.7; position: relative">
    <div class="card-img-overlay text-center home-banner" style="position: absolute; top: 10%">
        <h1 class="card-title display-6 fw-bold text-uppercase">3<sup>rd</sup> International conference on <br> <span class="text-warning">HUMANITIES AND SOCIAL SCIENCES-2024</span></h1>
        <p class="card-text fs-2 fw-bold">ICHSS-2024</p>
        <p class="card-text fs-2 fw-bold" id="app">

            <!-- Promoting Human Values, Creativity, Innovations and Prosperity to build Smart Generation for Smart Bangladesh -->
        </p>
        <p class="card-text fs-3 fw-bold ">
            18 & 19 February 2024, Sunday & Monday
        </p>
        <!-- <p class="card-text fs-2 fw-bold" data-aos="fade-up-right">JKKNIU Campus,</p> -->
        <p class="card-text fs-4 fw-bold"><small>Jatiya Kabi Kazi Nazrul Islam University Campus, Trishal, Mymensingh-2224, Bangladesh</small></p>
        <!-- <p class="card-text fs-4 fw-bold" data-aos="fade-up-right"><small>Trishal, Mymensingh-2224, Bangladesh</small></p> -->
    </div>
</div>
<nav class="navbar navbar-expand-lg bg_dark position-sticky top-0">
    <div class="container">
        <a class="navbar-brand" href="index.php"><img src="Images/jkkniu_logo.svg" alt="JKKNIU logo" style="width: 55px;"><span class="text-white"> Nazrul University Journal of Science and Engineering</span>
            <!-- <h2 class="text-white">Jatiya Kabi Kazi Nazrul University Journal Management System</h2> -->
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation" style="background-color: white;">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link fw-bold text-white navHover" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-bold text-white navHover" href="registration.php">Register</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link fw-bold text-white navHover" href="login.php">Login</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<marquee direction="left" height="30px" style="font-size: 1.2em;" width="100%">
    <p><strong>* <span style="color: #8B0000;">Our website is under construction now.</span> Stay tuned for further updates. *</strong></p>
</marquee>